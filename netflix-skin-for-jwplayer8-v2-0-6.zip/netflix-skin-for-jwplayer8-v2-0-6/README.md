# Netflix Skin for JWPLAYER8 v2.0.6

A Pen created on CodePen.io. Original URL: [https://codepen.io/iPingOi/pen/QRKbZG](https://codepen.io/iPingOi/pen/QRKbZG).

